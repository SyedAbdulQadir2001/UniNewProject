<!DOCTYPE html>
<!--suppress HtmlUnknownTarget -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signin Page</title>
    <link rel="stylesheet" href="<?php echo e(asset("/assets/css/authStyle.css")); ?>">
</head>
<body>

<div id="container">
    <div id="left">
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Silver_Jubilee_Gate_Karachi_University.jpg/1200px-Silver_Jubilee_Gate_Karachi_University.jpg" alt="University Image">
    </div>

    <div id="right">
        <div class="logo">
            <img src="/assets/images/logo.png" alt="" srcset="">
        </div>
        <h2>Sign In</h2>
        <form action="/login" method="POST" id="signup-form">
            <?php echo csrf_field(); ?>

            <?php if(session()->has("error")): ?>
            <div class="error">
                <?php echo e(session("error")); ?>

            </div>
            <?php endif; ?>

            <?php if(session()->has("message")): ?>
                <div class="error">
                    <?php echo e(session("message")); ?>

                </div>
            <?php endif; ?>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>


            <input class="btn" type="submit" value="Login">

        </form>
    </div>
</div>



</body>
</html>
<?php /**PATH C:\Users\Dell\Desktop\websites stuff\Dashboard\dashboard new\resources\views/pages/auth/login.blade.php ENDPATH**/ ?>

<!-- content-wrapper ends -->
<!-- partial:partials/_footer.html -->
<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
        <span class="text-muted d-block text-center text-sm-start d-sm-inline-block">Copyright © Karachi University 2023</span>

    </div>
</footer>
<!-- partial -->
<?php /**PATH C:\Users\Dell\Desktop\websites stuff\Dashboard\dashboard new\resources\views/components/dashboard/footer.blade.php ENDPATH**/ ?>
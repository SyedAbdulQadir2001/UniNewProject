<?php

namespace App\Http\Controllers\auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Auth\User;
use App\Models\Students;
use Illuminate\Support\Facades\DB;
use App\Models\Session;

date_default_timezone_set("Asia/Karachi");

class loginController extends Controller
{

    function Signup(Request $req){

        if($req->password === $req->confirm_password){
            $user = new User;
            $user->email = $req->email;
            $user->password = md5($req->password);
            $user->role = 0;
            $user->save();

            $id = User::where("email", $req->email)->first();

            Students::insert([
                "name" => $req->name,
                "fatherName" => null,
                "cnic" => null,
                "address" => null,
                "dob" => null,
                "rno" => null,
                "user_id" => $id->id,
            ]);

            return redirect("/dashboard");
        }else{
            // If Password or Confirm password not match redirect to Signup page with error
            return redirect("/");
        }

    }

    function Signin(Request $req){
        $users = User::where("email", $req->email)->where("password", md5($req->password))->first();

        if($users != null){
            session()->put("user_id", $users->id);
            return redirect("/dashboard");
        }

//        if($users != null){
//            $session = Session::where("user_id", $users->id)->count();
////            $login_at = Session::where("user_id", $users->id)->first();
//
//                if($session > 0){
//                    $test = Session::where("id", session()->getId())->get();
//                    if($test != null){
//                        Session::where("user_id", 1)->delete();
//                    }else{
//                        return "Failure";
//                    }
//
//                    session()->invalidate();
//                    session()->regenerateToken();
//                    Session::where("user_id", $users->id)->delete();
//                    return redirect("/");
//                    dd("hello from func");
//                }else{
//                    session()->put("user_id", $users->id);
//                    Session::insert([
//                        "id" => session()->getId(),
//                        "user_id" => $users->id,
//                        "user_agent" => $req->header('User-Agent'),
//                        "ip_address" => $req->ip(),
//                    ]);
//                    return redirect("/dashboard");
//                }
//            }else {
//            return redirect("/")->with("error", "Wrong Email or Password");
//        }
    }
}

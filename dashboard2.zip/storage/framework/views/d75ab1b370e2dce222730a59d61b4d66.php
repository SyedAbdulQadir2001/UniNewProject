
<!-- partial:partials/_sidebar.html -->
<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item nav-profile">
            <a href="/profile" class="nav-link">
                <div class="nav-profile-image">
                    <img src="<?php echo e(asset("assets/images/faces/face1.jpg")); ?>" alt="profile">
                    <span class="login-status online"></span>
                    <!--change to offline or busy as needed-->
                </div>
                <div class="nav-profile-text d-flex flex-column overflow-hidden">
                    <span class="font-weight-bold mb-2 text-truncate"><?php echo e($user->name); ?></span>
                    <span class="text-secondary text-small">
                        <?php
                            if($user_type ==0){
                                echo "Student";
                            }else if($user_type == 1){
                                echo "College";
                            }else if($user_type == 9999){
                                echo "Administrator";
                            }
                        ?> </span>
                </div>
                <i class="mdi mdi-bookmark-check text-success nav-profile-badge"></i>
            </a>
        </li>

        
        <?php if($user_type == 0): ?>
            <li class="nav-item">
                <a class="nav-link " href="/dashboard">
                    <span class="menu-title">Dashboard</span>
                    <i class="mdi mdi-home menu-icon"></i>
                </a>
            </li>
        
        <?php elseif($user_type == 1): ?>
            <li class="nav-item">
                <a class="nav-link" href="/dashboard">
                    <span class="menu-title">Dashboard</span>
                    <i class="mdi mdi-home menu-icon"></i>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="collapse" href="#exams">
                    <span class="menu-title">Exams</span>
                    <i class="menu-arrow"></i>
                    <i class="mdi mdi-book-open-page-variant menu-icon"></i>
                </a>

                <div class="collapse" id="exams">
                    <ul class="nav flex-column sub-menu">
                        <li class="nav-item"> <a class="nav-link" href="/exams/mbbs/mbbs-final-prof-conv">MBBS FINAL PROF (CONV)</a></li>
                        <li class="nav-item"> <a class="nav-link" href="/exams/mbbs/mbbs-final-prof-mod">MBBS FINAL PROF (MOD)</a></li>
                    </ul>
                </div>
            </li>


        
        <?php elseif($user_type == 9999): ?>
            <li class="nav-item">
                <a class="nav-link " href="/dashboard">
                    <span class="menu-title">Dashboard</span>
                    <i class="mdi mdi-home menu-icon"></i>
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link " href="/colleges">
                    <span class="menu-title">Colleges</span>
                    <i class="mdi mdi-school menu-icon"></i>
                </a>
            </li>















        <?php endif; ?>


























































    </ul>
</nav>
<!-- partial -->
<?php /**PATH C:\Users\Dell\Desktop\websites stuff\Dashboard\dashboard new\resources\views/components/dashboard/sidebar.blade.php ENDPATH**/ ?>
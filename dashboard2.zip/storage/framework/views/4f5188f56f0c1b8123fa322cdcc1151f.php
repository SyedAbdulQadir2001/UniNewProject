<?php $__env->startSection("title", "users"); ?>

<?php $__env->startSection("content"); ?>
    <div class="container-scroller">

        <?php if (isset($component)) { $__componentOriginalb6ee58394908b3e15421dd3072d4a76e = $component; } ?>
<?php $component = App\View\Components\Dashboard\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb6ee58394908b3e15421dd3072d4a76e)): ?>
<?php $component = $__componentOriginalb6ee58394908b3e15421dd3072d4a76e; ?>
<?php unset($__componentOriginalb6ee58394908b3e15421dd3072d4a76e); ?>
<?php endif; ?>


        <!-- partial -->
        <div class="container-fluid page-body-wrapper">

            <?php if (isset($component)) { $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce = $component; } ?>
<?php $component = App\View\Components\Dashboard\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce)): ?>
<?php $component = $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce; ?>
<?php unset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce); ?>
<?php endif; ?>

            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="page-header">


                        <h3 class="page-title"> Users </h3>
                        <a class="btn btn-behance" href="<?php echo e(route("users.create")); ?>">Add User</a>
                    </div>
                    <div class="row">
                        <div class="col-lg-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">

                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($user->id); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td>
                                                    <?php if($user->role == 0): ?>
                                                        Student
                                                    <?php elseif($user->role == 1): ?>
                                                        College
                                                    <?php elseif($user->role == 9999): ?>
                                                        Administrator
                                                    <?php endif; ?>
                                                </td>

                                                <td><a class="btn btn-success" href="<?php echo e(route("users.edit",$user->id)); ?>">Edit</a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>
                <!-- content-wrapper ends -->

                <?php if (isset($component)) { $__componentOriginal242504bb94b9c159c150822b98968500 = $component; } ?>
<?php $component = App\View\Components\Dashboard\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal242504bb94b9c159c150822b98968500)): ?>
<?php $component = $__componentOriginal242504bb94b9c159c150822b98968500; ?>
<?php unset($__componentOriginal242504bb94b9c159c150822b98968500); ?>
<?php endif; ?>
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.dashboard-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\websites stuff\Dashboard\dashboard updated\resources\views/pages/administrator/users/index.blade.php ENDPATH**/ ?>
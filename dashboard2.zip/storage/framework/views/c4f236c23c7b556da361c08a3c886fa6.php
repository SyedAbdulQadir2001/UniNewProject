<?php $__env->startSection("title", "Profile"); ?>

<?php $__env->startSection("content"); ?>
    <div class="container-scroller">

        <?php if (isset($component)) { $__componentOriginalb6ee58394908b3e15421dd3072d4a76e = $component; } ?>
<?php $component = App\View\Components\Dashboard\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb6ee58394908b3e15421dd3072d4a76e)): ?>
<?php $component = $__componentOriginalb6ee58394908b3e15421dd3072d4a76e; ?>
<?php unset($__componentOriginalb6ee58394908b3e15421dd3072d4a76e); ?>
<?php endif; ?>

        <div class="container-fluid page-body-wrapper">


           <?php if (isset($component)) { $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce = $component; } ?>
<?php $component = App\View\Components\Dashboard\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce)): ?>
<?php $component = $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce; ?>
<?php unset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce); ?>
<?php endif; ?>


            <div class="main-panel">
                <div class="content-wrapper">

                    <div class="row">

                        <div class="col-12 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">
                                    <h4 class="card-title">College Profile</h4>
                                    <p class="card-description"></p>
                                    <form action="/profile" method="POST" class="forms-sample">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="exampleInputName1">Title</label>
                                            <input type="text" class="form-control" id="exampleInputName1" name="title" value="<?php echo e($data->name); ?>" placeholder="Title">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputName1">Contact No</label>
                                            <input type="text" class="form-control" id="exampleInputName1" name="contact" value="<?php echo e($data->Contact); ?>" placeholder="Contact No">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputName1">Contact Person</label>
                                            <input type="text" class="form-control" id="exampleInputName1" name="contact_person" value="<?php echo e($data->Contact_Person); ?>" placeholder="Contact Person">
                                        </div>


                                        <div class="form-group">
                                            <label for="exampleInputEmail3">Email address</label>
                                            <input type="email" class="form-control" id="exampleInputEmail3" name="email" value="<?php echo e($data->Email); ?>" placeholder="Email">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputName1">Address</label>
                                            <input type="text" class="form-control" id="exampleInputName1" name="address" value="<?php echo e($data->Address); ?>" placeholder="Address">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputName1">Principal</label>
                                            <input type="text" class="form-control" id="exampleInputName1" name="principal" value="<?php echo e($data->Principal); ?>" placeholder="Principal">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleInputName1">Principal Contact No</label>
                                            <input type="text" class="form-control" id="exampleInputName1" name="principal_contact" value="<?php echo e($data->Principal_Contact); ?>" placeholder="Principal Contact No">
                                        </div>

                                        <div class="form-group">
                                            <label for="exampleSelectGender">Type</label>
                                            <select class="form-control" id="exampleSelectGender">
                                                <option value="0">Co-edu</option>
                                                <option value="1">Male</option>
                                                <option value="2">female</option>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label>Upload Picture</label>

                                            <div class="input-group col-xs-12">
                                                
                                                <input class="form-control" value="" type="file" name="profile_img" id="">
                                            </div>
                                        </div>

                                        <button type="submit" class="btn btn-gradient-primary me-2">Submit</button>
                                        <button class="btn btn-light">Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- content-wrapper ends -->
                <!-- partial:../../partials/_footer.html -->
                <?php if (isset($component)) { $__componentOriginal242504bb94b9c159c150822b98968500 = $component; } ?>
<?php $component = App\View\Components\Dashboard\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal242504bb94b9c159c150822b98968500)): ?>
<?php $component = $__componentOriginal242504bb94b9c159c150822b98968500; ?>
<?php unset($__componentOriginal242504bb94b9c159c150822b98968500); ?>
<?php endif; ?>
                <!-- partial -->
            </div>
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts/dashboard-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\websites stuff\Dashboard\dashboard new\resources\views/components/dashboard/profile/collages.blade.php ENDPATH**/ ?>
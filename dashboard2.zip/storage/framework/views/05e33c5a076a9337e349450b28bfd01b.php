<?php $__env->startSection("title", "users"); ?>

<?php $__env->startSection("content"); ?>
    <div class="container-scroller">

        <?php if (isset($component)) { $__componentOriginalb6ee58394908b3e15421dd3072d4a76e = $component; } ?>
<?php $component = App\View\Components\Dashboard\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Navbar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb6ee58394908b3e15421dd3072d4a76e)): ?>
<?php $component = $__componentOriginalb6ee58394908b3e15421dd3072d4a76e; ?>
<?php unset($__componentOriginalb6ee58394908b3e15421dd3072d4a76e); ?>
<?php endif; ?>


        <!-- partial -->
        <div class="container-fluid page-body-wrapper">

            <?php if (isset($component)) { $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce = $component; } ?>
<?php $component = App\View\Components\Dashboard\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Sidebar::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce)): ?>
<?php $component = $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce; ?>
<?php unset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce); ?>
<?php endif; ?>

            <div class="main-panel">
                <div class="content-wrapper">
                    <div class="page-header">
                        <h3 class="page-title"> Add User </h3>
                    </div>
                    <div class="row">
                        <div class="col-md-6 grid-margin stretch-card">
                            <div class="card">
                                <div class="card-body">


                                    <form class="forms-sample" action="<?php echo e(route("users.update",$users->id)); ?>" method="post">
                                        <?php echo method_field("PUT"); ?>
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label for="exampleInputEmail1">Email address</label>
                                            <input type="email" name="email" class="form-control" id="exampleInputEmail1" placeholder="Email" value="<?php echo e($users->email); ?>">
                                        </div>
                                        <div class="form-group">
                                            <label for="exampleInputPassword1">Password</label>
                                            <input type="password" name="password" class="form-control" id="exampleInputPassword1" placeholder="Password" value="<?php echo e(md5($users->password)); ?>">
                                        </div>

                                        <div class="form-group">
                                            <label for="">Role</label>
                                            <select class="form-control py-3" name="role" id="">
                                                <option selected>---- Select Role ----</option>
                                                <option value="0" <?php echo e(($users->role == 0) ? "Selected" : ""); ?>>Student</option>
                                                <option value="1" <?php echo e(($users->role == 1) ? "Selected" : ""); ?>>College</option>
                                                <option value="9999" <?php echo e(($users->role == 9999) ? "Selected" : ""); ?>>Administrator</option>
                                            </select>
                                        </div>

                                        <button type="submit" class="btn btn-gradient-primary me-2">Submit</button>
                                        <a class="btn btn-light" href="<?php echo e(route("users.index")); ?>">Cancel</a>

                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- content-wrapper ends -->
                <?php if (isset($component)) { $__componentOriginal242504bb94b9c159c150822b98968500 = $component; } ?>
<?php $component = App\View\Components\Dashboard\Footer::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Footer::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal242504bb94b9c159c150822b98968500)): ?>
<?php $component = $__componentOriginal242504bb94b9c159c150822b98968500; ?>
<?php unset($__componentOriginal242504bb94b9c159c150822b98968500); ?>
<?php endif; ?>
            </div>
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.dashboard-layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Dell\Desktop\websites stuff\Dashboard\dashboard updated\resources\views/pages/administrator/users/edit.blade.php ENDPATH**/ ?>
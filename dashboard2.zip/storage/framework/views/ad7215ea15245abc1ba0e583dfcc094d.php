<?php if($role === 0): ?>
    <?php if (isset($component)) { $__componentOriginalf3ea0d3c68ada9fda2a821023dea995b = $component; } ?>
<?php $component = App\View\Components\Dashboard\Profile\Student::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.profile.student'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Profile\Student::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf3ea0d3c68ada9fda2a821023dea995b)): ?>
<?php $component = $__componentOriginalf3ea0d3c68ada9fda2a821023dea995b; ?>
<?php unset($__componentOriginalf3ea0d3c68ada9fda2a821023dea995b); ?>
<?php endif; ?>
<?php elseif($role === 1): ?>
    <?php if (isset($component)) { $__componentOriginal59a48be1b6dc2a0c1da30110fe2bdd5c = $component; } ?>
<?php $component = App\View\Components\Dashboard\Profile\Collages::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard.profile.collages'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Dashboard\Profile\Collages::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal59a48be1b6dc2a0c1da30110fe2bdd5c)): ?>
<?php $component = $__componentOriginal59a48be1b6dc2a0c1da30110fe2bdd5c; ?>
<?php unset($__componentOriginal59a48be1b6dc2a0c1da30110fe2bdd5c); ?>
<?php endif; ?>
<?php endif; ?>
<?php /**PATH C:\Users\Dell\Desktop\websites stuff\Dashboard\dashboard updated\resources\views/pages/profile.blade.php ENDPATH**/ ?>